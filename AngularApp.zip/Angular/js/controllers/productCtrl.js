'use strict';

//Наш единственный контроллер
productmvc.controller('ProductCtrl', function ProductCtrl($scope, $location, productStorage) {
	var products = $scope.products = productStorage.get();

	$scope.$watch('products', function () { 
			productStorage.put(products);
	}, true);

	if ($location.path() === '') {
		$location.path('/');
	}


	$scope.addProduct = function () {
		if (!$scope.newProduct.length) {
			return;
		}

		products.push({
			title: $scope.newProduct
		});

		$scope.newProduct = '';
	};

	$scope.editProduct = function (product) {
		$scope.editedProduct = product;
	};

	$scope.doneEditing = function (product) {
		$scope.editedProduct = null;
		if (!product.title) {
			$scope.removeProduct(product);
		}
	};

	$scope.removeProduct = function (product) {
		products.splice(products.indexOf(product), 1);
	};
	
});
