	/*global productmvc */
'use strict';

/**
 * Служба для извлечения сохраненных товаров из локального хранилища.
 */
productmvc.factory('productStorage', function () {
	var STORAGE_ID = 'products-angularjs';

	return {
		get: function () {
			console.log("localStorage");
			console.log(localStorage);
			return JSON.parse(localStorage.getItem(STORAGE_ID) || '[]');
		},

		put: function (product) {
			console.log("product");
			console.log(product);
			localStorage.setItem(STORAGE_ID, JSON.stringify(product));
		}
	};
});
